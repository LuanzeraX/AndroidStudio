package com.example.checkpoint01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var users: MutableList<String> = mutableListOf("user1", "user2")
        var passwords: MutableList<String> = mutableListOf("pass1", "pass2")

        val buttonClear = findViewById<Button>(R.id.buttonClear)
        val user = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        var resultado = findViewById<TextView>(R.id.result)

        buttonClear.setOnClickListener {

            resultado.setText("")
            user.setText("")
            password.setText("")


        }

        val buttonCalc = findViewById<Button>(R.id.buttonCalc)

        buttonCalc.setOnClickListener{
            var resultado = findViewById<TextView>(R.id.result)
            val userInput = user.text.toString()
            val passwordInput = password.text.toString()



            if (userInput in users && passwordInput in passwords) {
                resultado.setText("Usuario logado com sucesso")
            }
            else if (userInput.isEmpty() && passwordInput.isEmpty()) {
                resultado.setText("Complete os campos!")
            }
            else if (userInput.isEmpty()) {
                resultado.setText("Usuario vazio, insira o usuario!")
            }

            else if (passwordInput.isEmpty()) {
                resultado.setText("Senha vazia, insira a senha!")
            }


            else {
                resultado.setText("Usuario ou Senha inexistente")
            }

                }






        }


    }




